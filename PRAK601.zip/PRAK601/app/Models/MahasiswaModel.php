<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $nama  = "Muhammad Alghifari";
    protected $nim   = "2110817110005";
    protected $prodi = "Teknologi Informasi";
    protected $hobi  = "Bermain game dan Healing";
    protected $skill = "Front end";
    protected $foto  = "IMG.jpg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getHobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getFoto()
    {
        return $this->foto;
    }
}